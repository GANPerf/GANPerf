
model_train.py   including the train phase, evaluation phase and testing phase
model_def.py   construct generator network and discriminator network
util.py  handle with datasets information

run python model_train.py

record.txt   recording the expermental results in Apache with 5n size of sample
results.doc   the expermental results in all datasets
